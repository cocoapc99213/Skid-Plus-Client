# くそClient decompiled by cocoapc911
wwwwwwwwwwwwww

<img src="lol.png" alt="koronnbia" width="100%"/>

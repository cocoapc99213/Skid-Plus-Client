// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.combat;

import net.minecraft.block.state.IBlockState;
import java.util.ArrayList;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketPlayer;
import me.alpha432.oyvey.util.MathUtil;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import me.alpha432.oyvey.features.modules.misc.AutoGG;
import me.alpha432.oyvey.util.BlockUtil;
import net.minecraft.util.EnumHand;
import me.alpha432.oyvey.OyVey;
import java.util.Comparator;
import me.alpha432.oyvey.features.command.Command;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.features.modules.Module;

public class PistonCrystal extends Module
{
    private Setting<redstone> redstoneType;
    private Setting<Integer> start_delay;
    private Setting<Integer> place_delay;
    private Setting<Integer> crystal_delay;
    private Setting<Integer> break_delay;
    private Setting<Integer> break_attempts;
    private Setting<types> target_type;
    private Setting<Integer> MaxY;
    private Setting<Float> range;
    private Setting<mode> trap;
    private Setting<Boolean> packetPlace;
    private Setting<arm> swingArm;
    private Setting<Boolean> antiweakness;
    private Setting<Boolean> toggle;
    public EntityPlayer target;
    private boolean r_redstone;
    private int b_stage;
    private BlockPos b_crystal;
    private BlockPos b_piston;
    private BlockPos b_redStone;
    private boolean p_crystal;
    private boolean p_piston;
    private boolean p_redstone;
    private boolean s_crystal;
    private boolean u_crystal;
    private int attempts;
    private int crystalId;
    private int trapprogress;
    private int timer;
    private boolean autoGG;
    private int debug_stage;
    private List<BlockPos> c_crystal;
    private List<BlockPos> c_piston;
    private List<BlockPos> c_redStone;
    private boolean isTorch;
    
    public PistonCrystal() {
        super("PistonCrystal", "Sleeping... :3", Category.COMBAT, true, false, false);
        this.redstoneType = (Setting<redstone>)this.register(new Setting("Redstone", (T)redstone.Both));
        this.start_delay = (Setting<Integer>)this.register(new Setting("Start Delay", (T)1, (T)0, (T)10));
        this.place_delay = (Setting<Integer>)this.register(new Setting("Place Delay", (T)1, (T)0, (T)10));
        this.crystal_delay = (Setting<Integer>)this.register(new Setting("Crystal Delay", (T)1, (T)0, (T)10));
        this.break_delay = (Setting<Integer>)this.register(new Setting("Break Delay", (T)1, (T)0, (T)10));
        this.break_attempts = (Setting<Integer>)this.register(new Setting("Break Attempts", (T)2, (T)1, (T)10));
        this.target_type = (Setting<types>)this.register(new Setting("Target", (T)types.Looking));
        this.MaxY = (Setting<Integer>)this.register(new Setting("MaxY", (T)2, (T)1, (T)5));
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)5.2f, (T)1.0f, (T)15.0f));
        this.trap = (Setting<mode>)this.register(new Setting("Trap Mode", (T)mode.Smart));
        this.packetPlace = (Setting<Boolean>)this.register(new Setting("PacketPlace", (T)false));
        this.swingArm = (Setting<arm>)this.register(new Setting("Swing Arm", (T)arm.MainHand));
        this.antiweakness = (Setting<Boolean>)this.register(new Setting("AntiWeakness", (T)false));
        this.toggle = (Setting<Boolean>)this.register(new Setting("Toggle", (T)true));
        this.target = null;
        this.r_redstone = false;
        this.b_stage = 0;
        this.b_crystal = null;
        this.b_piston = null;
        this.b_redStone = null;
        this.p_crystal = false;
        this.p_piston = false;
        this.p_redstone = false;
        this.s_crystal = false;
        this.u_crystal = false;
        this.attempts = 0;
        this.crystalId = 0;
        this.trapprogress = 0;
        this.timer = 0;
        this.autoGG = false;
        this.debug_stage = -1;
        this.c_crystal = null;
        this.c_piston = null;
        this.c_redStone = null;
        this.isTorch = false;
    }
    
    @Override
    public void onEnable() {
        this.Init();
        this.autoGG = false;
    }
    
    @Override
    public void onTick() {
        try {
            final int oldslot = PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
            final int pickaxe = this.findItem(Items.field_151046_w);
            final int crystal = this.findItem(Items.field_185158_cP);
            int piston = this.findMaterials((Block)Blocks.field_150331_J);
            if (piston == -1) {
                piston = this.findMaterials((Block)Blocks.field_150320_F);
            }
            int redstone = this.findMaterials(Blocks.field_150429_aA);
            this.isTorch = true;
            if (this.redstoneType.getValue() == PistonCrystal.redstone.Block || (this.redstoneType.getValue() == PistonCrystal.redstone.Both && redstone == -1)) {
                redstone = this.findMaterials(Blocks.field_150451_bX);
                this.isTorch = false;
            }
            final int obsidian = this.findMaterials(Blocks.field_150343_Z);
            int sword = this.findItem(Items.field_151048_u);
            if (this.antiweakness.getValue() && sword == -1) {
                sword = pickaxe;
            }
            if (pickaxe == -1 || crystal == -1 || piston == -1 || redstone == -1 || obsidian == -1) {
                Command.sendMessage("Missing Materials! disabling...");
                this.disable();
                return;
            }
            this.debug_stage = 0;
            if (this.target == null) {
                if (this.target_type.getValue() == types.Nearest) {
                    this.target = (EntityPlayer)PistonCrystal.mc.field_71441_e.field_73010_i.stream().filter(p -> p.field_145783_c != PistonCrystal.mc.field_71439_g.field_145783_c).min(Comparator.comparing(p -> PistonCrystal.mc.field_71439_g.func_70032_d(p))).orElse(null);
                }
                if (this.target_type.getValue() == types.Looking) {}
                if (this.target == null) {
                    this.disable();
                    return;
                }
            }
            this.debug_stage = 1;
            if (this.b_crystal == null || this.b_piston == null || this.b_redStone == null) {
                this.searchSpace();
                if (this.b_crystal == null || this.b_piston == null || this.b_redStone == null) {
                    if (this.toggle.getValue()) {
                        Command.sendMessage("Not found space! disabling...");
                        this.disable();
                    }
                    return;
                }
            }
            this.debug_stage = 2;
            if (this.getRange(this.b_crystal) > this.range.getValue() || this.getRange(this.b_piston) > this.range.getValue() || this.getRange(this.b_redStone) > this.range.getValue()) {
                Command.sendMessage("Out of range! disabling...");
                if (this.toggle.getValue()) {
                    this.disable();
                }
                return;
            }
            this.debug_stage = 3;
            final boolean doTrap = this.trap.getValue() == mode.Force || (this.trap.getValue() == mode.Smart && OyVey.holeManager.isSafe(PistonCrystal.mc.field_71439_g.func_180425_c()) && this.b_piston.func_177956_o() == PistonCrystal.mc.field_71439_g.func_180425_c().func_177956_o() + 1);
            if (doTrap && PistonCrystal.mc.field_71441_e.func_180495_p(new BlockPos(this.target.field_70165_t, this.target.field_70163_u + 2.0, this.target.field_70161_v)).func_177230_c() == Blocks.field_150350_a) {
                if (this.timer < this.place_delay.getValue()) {
                    ++this.timer;
                    return;
                }
                this.timer = 0;
                PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
                PistonCrystal.mc.field_71442_b.func_78765_e();
                final BlockPos first = new BlockPos((Math.floor(this.target.field_70165_t) - this.b_crystal.func_177958_n()) * 1.0 + this.target.field_70165_t, (double)this.b_piston.func_177956_o(), (Math.floor(this.target.field_70161_v) - this.b_crystal.func_177952_p()) * 1.0 + this.target.field_70161_v);
                if (this.trapprogress == 0 || this.trapprogress == 1) {
                    BlockPos pos = first;
                    if (this.trapprogress == 1) {
                        pos = new BlockPos(first.func_177958_n(), first.func_177956_o() + 1, first.func_177952_p());
                    }
                    BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, true, this.packetPlace.getValue(), false);
                }
                else {
                    BlockUtil.placeBlock(new BlockPos(this.target.field_70165_t, this.target.field_70163_u + 2.0, this.target.field_70161_v), EnumHand.MAIN_HAND, true, this.packetPlace.getValue(), false);
                }
                ++this.trapprogress;
            }
            else {
                this.debug_stage = 4;
                OyVey.moduleManager.getModuleByClass(AutoGG.class).addTargetedPlayer(this.target.func_70005_c_());
                this.debug_stage = 5;
                if (this.getBlock(this.b_piston.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150350_a) {
                    PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
                    PistonCrystal.mc.field_71442_b.func_78765_e();
                    if (this.timer < this.place_delay.getValue()) {
                        ++this.timer;
                        return;
                    }
                    this.timer = 0;
                    BlockUtil.placeBlock(this.b_piston.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, true, this.packetPlace.getValue(), false);
                }
                else if (this.getBlock(this.b_redStone.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150350_a && this.isTorch) {
                    PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = obsidian;
                    PistonCrystal.mc.field_71442_b.func_78765_e();
                    if (this.timer < this.place_delay.getValue()) {
                        ++this.timer;
                        return;
                    }
                    this.timer = 0;
                    BlockUtil.placeBlock(this.b_redStone.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, true, this.packetPlace.getValue(), false);
                }
                else {
                    this.debug_stage = 6;
                    if (this.r_redstone) {
                        if (this.getBlock(this.b_redStone).func_177230_c() == Blocks.field_150350_a) {
                            this.r_redstone = false;
                            this.b_stage = 0;
                            this.p_crystal = false;
                            this.p_redstone = false;
                            return;
                        }
                        PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = pickaxe;
                        PistonCrystal.mc.field_71442_b.func_78765_e();
                        if (this.b_stage == 0) {
                            PistonCrystal.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.b_redStone, EnumFacing.DOWN));
                            this.b_stage = 1;
                        }
                        else if (this.b_stage == 1) {
                            PistonCrystal.mc.field_71442_b.func_180512_c(this.b_redStone, EnumFacing.DOWN);
                        }
                    }
                    else {
                        this.debug_stage = 7;
                        if (!this.p_piston) {
                            if (this.timer < this.place_delay.getValue()) {
                                ++this.timer;
                                return;
                            }
                            this.timer = 0;
                            PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = piston;
                            PistonCrystal.mc.field_71442_b.func_78765_e();
                            final float[] angle = MathUtil.calcAngle(new Vec3d((Vec3i)this.b_piston), new Vec3d((Vec3i)this.b_crystal));
                            PistonCrystal.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(angle[0] + 180.0f, angle[1], true));
                            BlockUtil.placeBlock(this.b_piston, EnumHand.MAIN_HAND, false, this.packetPlace.getValue(), false);
                            this.p_piston = true;
                        }
                        this.debug_stage = 8;
                        if (!this.p_crystal) {
                            if (this.timer < this.crystal_delay.getValue()) {
                                ++this.timer;
                                return;
                            }
                            this.timer = 0;
                            if (crystal != 999) {
                                PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = crystal;
                            }
                            PistonCrystal.mc.field_71442_b.func_78765_e();
                            AutoCrystal.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(this.b_crystal, EnumFacing.UP, (PistonCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
                            this.p_crystal = true;
                        }
                        this.debug_stage = 9;
                        if (!this.p_redstone) {
                            if (this.timer < this.place_delay.getValue()) {
                                ++this.timer;
                                return;
                            }
                            this.timer = 0;
                            PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = redstone;
                            PistonCrystal.mc.field_71442_b.func_78765_e();
                            BlockUtil.placeBlock(this.b_redStone, EnumHand.MAIN_HAND, true, this.packetPlace.getValue(), false);
                            this.p_redstone = true;
                        }
                        this.debug_stage = 10;
                        if (this.p_crystal && this.p_piston && this.p_redstone && !this.u_crystal) {
                            if (this.timer < this.break_delay.getValue()) {
                                ++this.timer;
                                return;
                            }
                            this.timer = 0;
                            final Entity t_crystal = (Entity)PistonCrystal.mc.field_71441_e.field_72996_f.stream().filter(p -> p instanceof EntityEnderCrystal).min(Comparator.comparing(c -> this.target.func_70032_d(c))).orElse(null);
                            if (t_crystal == null) {
                                if (this.attempts < this.break_attempts.getValue()) {
                                    ++this.attempts;
                                    return;
                                }
                                this.attempts = 0;
                                Command.sendMessage("Not found crystal! retrying...");
                                this.r_redstone = true;
                                this.b_stage = 0;
                                return;
                            }
                            else {
                                this.crystalId = t_crystal.field_145783_c;
                                if (this.antiweakness.getValue()) {
                                    PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = sword;
                                    PistonCrystal.mc.field_71442_b.func_78765_e();
                                }
                                PistonCrystal.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(t_crystal));
                                if (this.swingArm.getValue() != arm.None) {
                                    PistonCrystal.mc.field_71439_g.func_184609_a((this.swingArm.getValue() == arm.MainHand) ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND);
                                }
                                this.u_crystal = true;
                            }
                        }
                        this.debug_stage = 11;
                        if (this.u_crystal) {
                            if (this.timer < this.break_delay.getValue()) {
                                ++this.timer;
                                return;
                            }
                            this.timer = 0;
                            this.Init();
                        }
                        else {
                            PistonCrystal.mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
                            PistonCrystal.mc.field_71442_b.func_78765_e();
                        }
                    }
                }
            }
        }
        catch (Exception ex) {
            Command.sendMessage("Has Error! : " + ex.toString());
            Command.sendMessage("Stage : " + this.debug_stage);
            Command.sendMessage("Trying to init...");
            this.Init();
        }
    }
    
    private int findMaterials(final Block b) {
        for (int i = 0; i < 9; ++i) {
            if (PistonCrystal.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)PistonCrystal.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).func_179223_d() == b) {
                return i;
            }
        }
        return -1;
    }
    
    private int findItem(final Item item) {
        if (item == Items.field_185158_cP && PistonCrystal.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            return 999;
        }
        for (int i = 0; i < 9; ++i) {
            if (PistonCrystal.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == item) {
                return i;
            }
        }
        return -1;
    }
    
    private void searchSpace() {
        final BlockPos floored_pos = new BlockPos(this.target.field_70165_t, this.target.field_70163_u, this.target.field_70161_v);
        final BlockPos[] offset = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
        this.debug_stage = -2;
        for (int y = 0; y < this.MaxY.getValue() + 1; ++y) {
            for (int i = 0; i < offset.length; ++i) {
                this.sp(offset[i], y, floored_pos);
            }
        }
        this.debug_stage = -3;
        this.b_crystal = this.c_crystal.stream().min(Comparator.comparing(b -> PistonCrystal.mc.field_71439_g.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p()))).orElse(null);
        this.b_piston = this.c_piston.stream().min(Comparator.comparing(b -> this.b_crystal.func_177951_i(b))).orElse(null);
        if (this.b_piston != null) {
            this.b_redStone = this.c_redStone.stream().filter(b -> this.b_piston.func_185332_f(b.func_177958_n(), b.func_177956_o(), b.func_177952_p()) < 2.0).min(Comparator.comparing(b -> this.b_crystal.func_177951_i(b))).orElse(null);
        }
        this.debug_stage = -4;
        if (this.b_crystal == null) {
            return;
        }
        if (this.getBlock(this.b_crystal.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150332_K && this.getBlock(this.b_redStone).func_177230_c() == this.getRedStoneBlock()) {
            this.r_redstone = true;
            this.b_stage = 0;
        }
        this.debug_stage = -5;
    }
    
    private void sp(final BlockPos offset, final int offset_y, final BlockPos enemy_pos) {
        final BlockPos mypos = new BlockPos(PistonCrystal.mc.field_71439_g.field_70165_t, PistonCrystal.mc.field_71439_g.field_70163_u, PistonCrystal.mc.field_71439_g.field_70161_v);
        boolean v_crystal = false;
        boolean v_piston = false;
        boolean v_redstone = false;
        final BlockPos pre_crystal = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n(), enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y, enemy_pos.func_177952_p() + offset.func_177952_p());
        final BlockPos pre_piston = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 2);
        BlockPos pre_redstone = new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 3);
        if (this.checkBlock(this.getBlock(pre_crystal).func_177230_c()) && this.isAir(this.getBlock(pre_crystal.func_177982_a(0, 1, 0)).func_177230_c()) && this.isAir(this.getBlock(pre_crystal.func_177982_a(0, 2, 0)).func_177230_c())) {
            v_crystal = true;
        }
        if (this.isAir(this.getBlock(pre_piston).func_177230_c())) {
            v_piston = true;
        }
        if (this.isTorch) {
            final BlockPos[] t_offset = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
            final List<BlockPos> pre_redstone_place = new ArrayList<BlockPos>();
            final BlockPos tmp = null;
            for (int o = 0; o < t_offset.length; ++o) {
                final BlockPos pre_redstone_offset = pre_piston.func_177971_a((Vec3i)t_offset[o]);
                if (this.isAir(this.getBlock(pre_redstone_offset).func_177230_c()) && (pre_redstone_offset.func_177958_n() != mypos.func_177958_n() || (pre_redstone_offset.func_177956_o() != mypos.func_177956_o() && pre_redstone_offset.func_177956_o() != mypos.func_177956_o() + 1) || pre_redstone_offset.func_177952_p() != mypos.func_177952_p()) && pre_crystal.func_185332_f(pre_redstone_offset.func_177958_n(), pre_redstone_offset.func_177956_o(), pre_redstone_offset.func_177952_p()) > 1.0) {
                    pre_redstone_place.add(pre_redstone_offset);
                }
            }
            if (this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150350_a && this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 1, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150343_Z) {
                pre_redstone_place.add(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3));
            }
            if (this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 3, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 3)).func_177230_c() == Blocks.field_150343_Z) {
                pre_redstone_place.add(new BlockPos(enemy_pos.func_177958_n() + offset.func_177958_n() * 2, enemy_pos.func_177956_o() + offset.func_177956_o() + offset_y + 2, enemy_pos.func_177952_p() + offset.func_177952_p() * 2));
            }
            pre_redstone = pre_redstone_place.stream().min(Comparator.comparing(b -> PistonCrystal.mc.field_71439_g.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p()))).orElse(null);
            if (pre_redstone != null) {
                v_redstone = true;
            }
        }
        else if (this.isAir(this.getBlock(pre_redstone).func_177230_c())) {
            v_redstone = true;
        }
        if (pre_piston.func_177958_n() == mypos.func_177958_n() && (pre_piston.func_177956_o() == mypos.func_177956_o() || pre_piston.func_177956_o() == mypos.func_177956_o() + 1) && pre_piston.func_177952_p() == mypos.func_177952_p()) {
            v_piston = false;
        }
        if (pre_redstone != null && pre_redstone.func_177958_n() == mypos.func_177958_n() && (pre_redstone.func_177956_o() == mypos.func_177956_o() || pre_redstone.func_177956_o() == mypos.func_177956_o() + 1) && pre_redstone.func_177952_p() == mypos.func_177952_p()) {
            v_redstone = false;
        }
        if (mypos.func_185332_f(pre_piston.func_177958_n(), mypos.func_177956_o(), pre_piston.func_177952_p()) < 3.1 && pre_piston.func_177956_o() > mypos.func_177956_o() + 1) {
            v_piston = false;
        }
        if (this.getBlock(pre_crystal.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150332_K && (this.getBlock(pre_redstone).func_177230_c() == Blocks.field_150451_bX || this.getBlock(pre_redstone).func_177230_c() == Blocks.field_150429_aA)) {
            v_piston = true;
            v_crystal = true;
            v_redstone = true;
        }
        if (v_crystal && v_piston && v_redstone) {
            this.c_crystal.add(pre_crystal);
            this.c_piston.add(pre_piston);
            this.c_redStone.add(pre_redstone);
        }
    }
    
    private void Init() {
        this.target = null;
        this.b_crystal = null;
        this.b_piston = null;
        this.b_redStone = null;
        this.c_crystal = new ArrayList<BlockPos>();
        this.c_piston = new ArrayList<BlockPos>();
        this.c_redStone = new ArrayList<BlockPos>();
        this.p_crystal = false;
        this.p_piston = false;
        this.p_redstone = false;
        this.u_crystal = false;
        this.attempts = 0;
        this.r_redstone = false;
        this.b_stage = 0;
        this.trapprogress = 0;
        this.timer = 0;
        this.crystalId = 0;
        this.debug_stage = -1;
    }
    
    private float getRange(final BlockPos t) {
        return (float)PistonCrystal.mc.field_71439_g.func_70011_f((double)t.func_177958_n(), (double)t.func_177956_o(), (double)t.func_177952_p());
    }
    
    private boolean isAir(final Block b) {
        return b == Blocks.field_150350_a;
    }
    
    private boolean checkBlock(final Block b) {
        return b == Blocks.field_150343_Z || b == Blocks.field_150357_h;
    }
    
    private IBlockState getBlock(final BlockPos o) {
        return PistonCrystal.mc.field_71441_e.func_180495_p(o);
    }
    
    private double f(final double v) {
        return Math.floor(v);
    }
    
    private Block getRedStoneBlock() {
        return this.isTorch ? Blocks.field_150429_aA : Blocks.field_150451_bX;
    }
    
    private enum types
    {
        Nearest, 
        Looking;
    }
    
    private enum arm
    {
        MainHand, 
        OffHand, 
        None;
    }
    
    private enum redstone
    {
        Block, 
        Torch, 
        Both;
    }
    
    private enum mode
    {
        Smart, 
        Force, 
        None;
    }
}

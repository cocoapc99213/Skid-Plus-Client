// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class Scaffold extends Module
{
    public Scaffold() {
        super("Scaffold", "Scaffold.", Category.MOVEMENT, true, false, false);
    }
}

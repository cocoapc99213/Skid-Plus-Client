// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class PacketFly extends Module
{
    public PacketFly() {
        super("PacketFly", "PacketFly.", Category.MOVEMENT, true, false, false);
    }
}

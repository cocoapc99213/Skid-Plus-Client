// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.Timer;
import me.alpha432.oyvey.features.modules.Module;

public class VanillaFly extends Module
{
    private final Timer timer;
    public Setting<Float> Speed;
    
    public VanillaFly() {
        super("vanillaFlyTest", "Fly", Category.MOVEMENT, true, false, false);
        this.timer = new Timer();
        this.Speed = (Setting<Float>)this.register(new Setting("Speed", (T)4.0f, (T)0.1f, (T)20.0f));
    }
    
    @Override
    public void onEnable() {
        VanillaFly.mc.field_71439_g.field_71075_bZ.field_75101_c = true;
        VanillaFly.mc.field_71439_g.field_71075_bZ.field_75100_b = true;
    }
    
    @Override
    public void onDisable() {
        VanillaFly.mc.field_71439_g.field_71075_bZ.field_75101_c = false;
        VanillaFly.mc.field_71439_g.field_71075_bZ.field_75100_b = false;
    }
}

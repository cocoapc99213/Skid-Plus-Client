// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.combat;

import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.Packet;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.item.ItemBow;
import me.alpha432.oyvey.features.modules.Module;

public class FastBow extends Module
{
    public FastBow() {
        super("FastBow", "Teleports you.", Category.COMBAT, true, false, false);
    }
    
    @Override
    public void onUpdate() {
        if (FastBow.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow && FastBow.mc.field_71439_g.func_184587_cr() && FastBow.mc.field_71439_g.func_184612_cw() >= 3) {
            FastBow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, FastBow.mc.field_71439_g.func_174811_aO()));
            FastBow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(FastBow.mc.field_71439_g.func_184600_cs()));
            FastBow.mc.field_71439_g.func_184597_cx();
        }
    }
}

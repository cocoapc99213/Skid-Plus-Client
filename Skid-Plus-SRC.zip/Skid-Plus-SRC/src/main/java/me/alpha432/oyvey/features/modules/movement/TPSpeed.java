// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Objects;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.alpha432.oyvey.util.MathUtil;
import me.alpha432.oyvey.event.events.UpdateWalkingPlayerEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.features.modules.Module;

public class TPSpeed extends Module
{
    private final Setting<Mode> mode;
    private final Setting<Double> speed;
    private final Setting<Double> fallSpeed;
    private final Setting<Boolean> turnOff;
    private final Setting<Integer> tpLimit;
    private int tps;
    private final double[] selectedPositions;
    
    public TPSpeed() {
        super("TpSpeed", "Teleports you.", Category.MOVEMENT, true, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.NORMAL));
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)0.25, (T)0.1, (T)10.0));
        this.fallSpeed = (Setting<Double>)this.register(new Setting("FallSpeed", (T)0.25, (T)0.1, (T)10.0, v -> this.mode.getValue() == Mode.STEP));
        this.turnOff = (Setting<Boolean>)this.register(new Setting("Off", (T)false));
        this.tpLimit = (Setting<Integer>)this.register(new Setting("Limit", (T)2, (T)1, (T)10, v -> this.turnOff.getValue(), "Turn it off."));
        this.tps = 0;
        this.selectedPositions = new double[] { 0.42, 0.75, 1.0 };
    }
    
    private static boolean collidesHorizontally(final AxisAlignedBB bb) {
        if (TPSpeed.mc.field_71441_e.func_184143_b(bb)) {
            final Vec3d center = bb.func_189972_c();
            final BlockPos blockpos = new BlockPos(center.field_72450_a, bb.field_72338_b, center.field_72449_c);
            return TPSpeed.mc.field_71441_e.func_175665_u(blockpos.func_177976_e()) || TPSpeed.mc.field_71441_e.func_175665_u(blockpos.func_177974_f()) || TPSpeed.mc.field_71441_e.func_175665_u(blockpos.func_177978_c()) || TPSpeed.mc.field_71441_e.func_175665_u(blockpos.func_177968_d()) || TPSpeed.mc.field_71441_e.func_175665_u(blockpos);
        }
        return false;
    }
    
    @Override
    public void onEnable() {
        this.tps = 0;
    }
    
    @SubscribeEvent
    public void onUpdatePlayerWalking(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() != 0) {
            return;
        }
        if (this.mode.getValue() == Mode.NORMAL) {
            if (this.turnOff.getValue() && this.tps >= this.tpLimit.getValue()) {
                this.disable();
                return;
            }
            if (TPSpeed.mc.field_71439_g.field_191988_bg != 0.0f || (TPSpeed.mc.field_71439_g.field_70702_br != 0.0f && TPSpeed.mc.field_71439_g.field_70122_E)) {
                for (double x = 0.0625; x < this.speed.getValue(); x += 0.262) {
                    final double[] dir = MathUtil.directionSpeed(x);
                    TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + dir[0], TPSpeed.mc.field_71439_g.field_70163_u, TPSpeed.mc.field_71439_g.field_70161_v + dir[1], TPSpeed.mc.field_71439_g.field_70122_E));
                }
                TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + TPSpeed.mc.field_71439_g.field_70159_w, 0.0, TPSpeed.mc.field_71439_g.field_70161_v + TPSpeed.mc.field_71439_g.field_70179_y, TPSpeed.mc.field_71439_g.field_70122_E));
                ++this.tps;
            }
        }
        else if ((TPSpeed.mc.field_71439_g.field_191988_bg != 0.0f || TPSpeed.mc.field_71439_g.field_70702_br != 0.0f) && TPSpeed.mc.field_71439_g.field_70122_E) {
            double pawnY = 0.0;
            final double[] lastStep = MathUtil.directionSpeed(0.262);
            for (double x2 = 0.0625; x2 < this.speed.getValue(); x2 += 0.262) {
                double[] dir2;
                AxisAlignedBB bb;
                double[] selectedPositions;
                int length;
                int j;
                double position;
                for (dir2 = MathUtil.directionSpeed(x2), bb = Objects.requireNonNull(TPSpeed.mc.field_71439_g.func_174813_aQ()).func_72317_d(dir2[0], pawnY, dir2[1]); collidesHorizontally(bb); bb = Objects.requireNonNull(TPSpeed.mc.field_71439_g.func_174813_aQ()).func_72317_d(dir2[0], ++pawnY, dir2[1])) {
                    selectedPositions = this.selectedPositions;
                    for (length = selectedPositions.length, j = 0; j < length; ++j) {
                        position = selectedPositions[j];
                        TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + dir2[0] - lastStep[0], TPSpeed.mc.field_71439_g.field_70163_u + pawnY + position, TPSpeed.mc.field_71439_g.field_70161_v + dir2[1] - lastStep[1], true));
                    }
                }
                if (!TPSpeed.mc.field_71441_e.func_72829_c(bb.func_72314_b(0.0125, 0.0, 0.0125).func_72317_d(0.0, -1.0, 0.0))) {
                    for (double i = 0.0; i <= 1.0; i += this.fallSpeed.getValue()) {
                        TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + dir2[0], TPSpeed.mc.field_71439_g.field_70163_u + pawnY - i, TPSpeed.mc.field_71439_g.field_70161_v + dir2[1], true));
                    }
                    --pawnY;
                }
                TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + dir2[0], TPSpeed.mc.field_71439_g.field_70163_u + pawnY, TPSpeed.mc.field_71439_g.field_70161_v + dir2[1], TPSpeed.mc.field_71439_g.field_70122_E));
            }
            TPSpeed.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(TPSpeed.mc.field_71439_g.field_70165_t + TPSpeed.mc.field_71439_g.field_70159_w, 0.0, TPSpeed.mc.field_71439_g.field_70161_v + TPSpeed.mc.field_71439_g.field_70179_y, TPSpeed.mc.field_71439_g.field_70122_E));
        }
    }
    
    public enum Mode
    {
        NORMAL, 
        STEP;
    }
}

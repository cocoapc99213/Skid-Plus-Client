// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.combat;

import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.util.math.Vec3i;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import me.alpha432.oyvey.util.BlockUtil;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import me.alpha432.oyvey.features.command.Command;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import java.util.ArrayList;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import java.util.List;
import me.alpha432.oyvey.features.modules.Module;

public class CevBreaker extends Module
{
    private List<BlockPos> placeList;
    private boolean placing;
    private boolean placedCrystal;
    private boolean breaking;
    private boolean broke;
    private EntityPlayer _target;
    private BlockPos b_crystal;
    private BlockPos breakPos;
    private int attempts;
    private Setting<type> targetType;
    private Setting<mode> breakMode;
    private Setting<Boolean> rotate;
    private Setting<Integer> startDelay;
    private Setting<Integer> breakDelay;
    private Setting<Integer> crystalDelay;
    private Setting<Integer> breakAttempts;
    private int timer;
    
    public CevBreaker() {
        super("CevBreaker", "Attack Ceil", Category.COMBAT, true, false, false);
        this.placeList = new ArrayList<BlockPos>();
        this.placing = false;
        this.placedCrystal = false;
        this.breaking = false;
        this.broke = false;
        this._target = null;
        this.b_crystal = null;
        this.breakPos = null;
        this.attempts = 0;
        this.targetType = (Setting<type>)this.register(new Setting("Target", (T)type.NEAREST));
        this.breakMode = (Setting<mode>)this.register(new Setting("Break Mode", (T)mode.Vanilla));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.startDelay = (Setting<Integer>)this.register(new Setting("Start Delay", (T)1, (T)0, (T)10));
        this.breakDelay = (Setting<Integer>)this.register(new Setting("Break Delay", (T)1, (T)0, (T)10));
        this.crystalDelay = (Setting<Integer>)this.register(new Setting("Crystal Delay", (T)1, (T)0, (T)10));
        this.breakAttempts = (Setting<Integer>)this.register(new Setting("Break Attempts", (T)3, (T)0, (T)10));
        this.timer = 0;
    }
    
    @Override
    public void onEnable() {
        this.init();
    }
    
    private void init() {
        this.placeList = new ArrayList<BlockPos>();
        this._target = null;
        this.b_crystal = null;
        this.placedCrystal = false;
        this.placing = false;
        this.breaking = false;
        this.broke = false;
        this.timer = 0;
        this.attempts = 0;
    }
    
    @Override
    public void onTick() {
        final int pix = this.findItem(Items.field_151046_w);
        final int crystal = this.findItem(Items.field_185158_cP);
        final int obby = this.findMaterials(Blocks.field_150343_Z);
        if (pix == -1 || crystal == -1 || obby == -1) {
            Command.sendMessage("Missing Materials! disabling....");
            this.disable();
            return;
        }
        if (this._target == null) {
            if (this.targetType.getValue() == type.NEAREST) {
                this._target = (EntityPlayer)CevBreaker.mc.field_71441_e.field_73010_i.stream().filter(p -> p.field_145783_c != CevBreaker.mc.field_71439_g.field_145783_c).min(Comparator.comparing(p -> p.func_70032_d((Entity)CevBreaker.mc.field_71439_g))).orElse(null);
            }
            if (this._target == null) {
                this.disable();
                return;
            }
        }
        if (this.placeList.size() == 0 && !this.placing) {
            this.searchSpace();
            if (this.placeList.size() == 0) {
                Command.sendMessage("Not found space! disabling...");
                this.disable();
                return;
            }
        }
        if (!this.placedCrystal) {
            if (this.timer < this.startDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            this.doPlace(obby, crystal);
        }
        else if (!this.breaking) {
            if (this.timer < this.breakDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            if (this.breakMode.getValue() == mode.Vanilla) {
                CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = pix;
                CevBreaker.mc.field_71442_b.func_78765_e();
                CevBreaker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                CevBreaker.mc.field_71442_b.func_180512_c(this.breakPos, EnumFacing.DOWN);
            }
            else {
                CevBreaker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
            }
            this.breaking = true;
        }
        else if (this.breaking && !this.broke) {
            if (this.getBlock(this.breakPos) == Blocks.field_150350_a) {
                this.broke = true;
            }
        }
        else if (this.broke) {
            if (this.timer < this.crystalDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            final Entity bcrystal = (Entity)CevBreaker.mc.field_71441_e.field_72996_f.stream().filter(e -> e instanceof EntityEnderCrystal).min(Comparator.comparing(c -> c.func_70032_d((Entity)this._target))).orElse(null);
            if (bcrystal == null) {
                if (this.attempts < this.breakAttempts.getValue()) {
                    ++this.attempts;
                    return;
                }
                Command.sendMessage("Not found crystal! retrying...");
                this.placedCrystal = false;
                this.placeList.add(this.breakPos);
                this.breaking = false;
                this.broke = false;
                this.attempts = 0;
            }
            else {
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(bcrystal));
                this.placedCrystal = false;
                this.placeList.add(this.breakPos);
                this.breaking = false;
                this.broke = false;
                this.attempts = 0;
            }
        }
    }
    
    private void doPlace(final int obby, final int crystal) {
        this.placing = true;
        if (this.placeList.size() != 0) {
            final int oldslot = CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c;
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = obby;
            CevBreaker.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(this.placeList.get(0), EnumHand.MAIN_HAND, this.rotate.getValue(), false, false);
            this.placeList.remove(0);
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
        }
        else if (!this.placedCrystal) {
            final int oldslot = CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c;
            if (crystal != 999) {
                CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = crystal;
            }
            CevBreaker.mc.field_71442_b.func_78765_e();
            CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(this.b_crystal, EnumFacing.UP, (CevBreaker.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
            this.placedCrystal = true;
        }
    }
    
    private void searchSpace() {
        final BlockPos ppos = CevBreaker.mc.field_71439_g.func_180425_c();
        final BlockPos tpos = new BlockPos(this._target.field_70165_t, this._target.field_70163_u, this._target.field_70161_v);
        this.placeList = new ArrayList<BlockPos>();
        final BlockPos[] offset = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
        if (this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 3, tpos.func_177952_p())) != Blocks.field_150350_a || this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 4, tpos.func_177952_p())) != Blocks.field_150350_a) {
            return;
        }
        final List<BlockPos> posList = new ArrayList<BlockPos>();
        for (int i = 0; i < offset.length; ++i) {
            final BlockPos offsetPos = tpos.func_177971_a((Vec3i)offset[i]);
            final Block block = this.getBlock(offsetPos);
            if (block != Blocks.field_150350_a && !(block instanceof BlockLiquid)) {
                posList.add(offsetPos);
            }
        }
        final BlockPos base = posList.stream().max(Comparator.comparing(b -> this._target.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p()))).orElse(null);
        if (base == null) {
            return;
        }
        this.placeList.add(base);
        this.placeList.add(base.func_177982_a(0, 1, 0));
        this.placeList.add(base.func_177982_a(0, 2, 0));
        this.placeList.add(tpos.func_177982_a(0, 2, 0));
        this.breakPos = tpos.func_177982_a(0, 2, 0);
        this.b_crystal = tpos.func_177982_a(0, 2, 0);
    }
    
    private int findMaterials(final Block b) {
        for (int i = 0; i < 9; ++i) {
            if (CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock && ((ItemBlock)CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).func_179223_d() == b) {
                return i;
            }
        }
        return -1;
    }
    
    private int findItem(final Item item) {
        if (item == Items.field_185158_cP && CevBreaker.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            return 999;
        }
        for (int i = 0; i < 9; ++i) {
            if (CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == item) {
                return i;
            }
        }
        return -1;
    }
    
    private Block getBlock(final BlockPos b) {
        return CevBreaker.mc.field_71441_e.func_180495_p(b).func_177230_c();
    }
    
    public enum type
    {
        NEAREST, 
        LOOKING;
    }
    
    public enum mode
    {
        Vanilla, 
        Packet;
    }
}

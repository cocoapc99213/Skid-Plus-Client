// 
// Decompiled by Procyon v0.5.36
// 

package me.alpha432.oyvey.features.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import me.alpha432.oyvey.util.Timer;
import me.alpha432.oyvey.features.modules.Module;

public class NCPBhop extends Module
{
    private final Timer timer;
    
    public NCPBhop() {
        super("NCPBhop", "NCPBypass.", Category.MOVEMENT, true, false, false);
        this.timer = new Timer();
    }
    
    @Override
    public void onUpdate() {
        if (NCPBhop.mc.field_71439_g.field_191988_bg > 0.0f || NCPBhop.mc.field_71439_g.field_70702_br > 0.0f) {
            if (NCPBhop.mc.field_71439_g.field_70122_E) {
                final double timerSpeed = 1.0;
                NCPBhop.mc.field_71439_g.func_70664_aZ();
                final EntityPlayerSP field_71439_g = NCPBhop.mc.field_71439_g;
                field_71439_g.field_70159_w *= 1.0227999687194824;
                final EntityPlayerSP field_71439_g2 = NCPBhop.mc.field_71439_g;
                field_71439_g2.field_70179_y *= 1.0227999687194824;
            }
            else {
                if (NCPBhop.mc.field_71439_g.field_70173_aa % 3 == 0) {}
                final EntityPlayerSP field_71439_g3 = NCPBhop.mc.field_71439_g;
                field_71439_g3.field_70159_w *= 1.0;
                final EntityPlayerSP field_71439_g4 = NCPBhop.mc.field_71439_g;
                field_71439_g4.field_70179_y *= 1.0;
                NCPBhop.mc.field_71439_g.field_70747_aH = 0.0265f;
                final EntityPlayerSP field_71439_g5 = NCPBhop.mc.field_71439_g;
                field_71439_g5.field_70702_br *= 1.0f;
                final EntityPlayerSP field_71439_g6 = NCPBhop.mc.field_71439_g;
                field_71439_g6.field_191988_bg *= 1.0f;
                if (NCPBhop.mc.field_71439_g.field_70143_R >= 0.3) {
                    final double timerSpeed = 1.2000000476837158;
                    final EntityPlayerSP field_71439_g7 = NCPBhop.mc.field_71439_g;
                    field_71439_g7.field_70181_x -= 62.0;
                }
            }
        }
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
        final double timerSpeed = 1.0;
    }
}
